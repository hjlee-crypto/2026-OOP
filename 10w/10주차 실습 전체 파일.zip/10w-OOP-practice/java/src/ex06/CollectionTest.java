package ex06;
import java.util.List;
import java.util.Map;
public class CollectionTest {
    public static <T> void printItem(T item) {
        System.out.println(item);
    }
    public static void main(String[] args) {
        List<String> accounts = List.of("A-001", "A-002");
        Map<String, Integer> balances = Map.of(
            "A-001", 100000, "A-002", 50000);
        printItem(accounts.get(0));
        System.out.println(balances.get("A-002"));
        System.out.println(accounts.size());
    }
}
