package ex05;
public class GenericTest {
    public static void main(String[] args) {
        Box<String> account = new Box<>();
        account.set("A-001");
        Box<Integer> balance = new Box<>();
        balance.set(100000);
        System.out.println(account.get());
        System.out.println(balance.get());
    }
}
