package ex02;
public class LambdaTest {
    public static void main(String[] args) {
        InterestPolicy savings = balance -> balance * 0.03;
        InterestPolicy deposit = balance -> balance * 0.05;
        System.out.println(savings.calculate(100000));
        System.out.println(deposit.calculate(100000));
    }
}
