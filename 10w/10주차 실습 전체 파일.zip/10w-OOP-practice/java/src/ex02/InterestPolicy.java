package ex02;
@FunctionalInterface
public interface InterestPolicy {
    double calculate(int balance);
}
