package ex07;
public class Account {
    private final String number;
    private int balance;
    public Account(String number, int balance) {
        this.number = number;
        this.balance = balance;
    }
    public String getNumber() { return number; }
    public int getBalance() { return balance; }
    public void deposit(int amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("입금액은 양수여야 합니다.");
        }
        balance += amount;
    }
}
