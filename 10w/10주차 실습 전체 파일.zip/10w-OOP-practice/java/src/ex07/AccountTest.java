package ex07;
public class AccountTest {
    public static void main(String[] args) {
        Account a = new Account("A-001", 100000);
        a.deposit(50000);
        System.out.println(a.getNumber());
        System.out.println(a.getBalance());
    }
}
