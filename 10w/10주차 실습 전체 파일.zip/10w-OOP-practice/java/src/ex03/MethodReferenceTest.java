package ex03;
import java.util.List;
public class MethodReferenceTest {
    public static void main(String[] args) {
        List<String> numbers = List.of("A-001", "A-002");
        numbers.forEach(n -> System.out.println(n));
        System.out.println("---");
        numbers.forEach(System.out::println);
    }
}
