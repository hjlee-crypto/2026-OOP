@FunctionalInterface
public interface InterestPolicy {
    double calculate(int balance);
}
