import java.util.ArrayList;
import java.util.List;

public class BankTest {
    public static void main(String[] args) {
        List<Account> accounts = new ArrayList<>();
        accounts.add(new Account("A-001", 50000));
        accounts.add(new Account("A-002", 120000));
        accounts.add(new Account("A-003", 200000));

        System.out.println("[1] 전체 계좌");
        accounts.forEach(System.out::println);

        System.out.println("[2] 잔액 100000원 이상");
        accounts.stream()
                .filter(account -> account.getBalance() >= 100000)
                .forEach(System.out::println);

        InterestPolicy policy = balance -> balance * 0.03;
        System.out.println("[3] A-002 이자: "
                + policy.calculate(accounts.get(1).getBalance()));

        Box<Account> box = new Box<>();
        box.set(accounts.get(0));
        System.out.println("[4] Box에 보관한 계좌: " + box.get());

        Account first = accounts.get(0);
        first.deposit(10000);
        first.withdraw(5000);
        System.out.println("[5] 입출금 후 잔액: " + first.getBalance());

        System.out.println("[6] 잘못된 출금 검증");
        try {
            first.withdraw(1000000);
        } catch (IllegalArgumentException e) {
            System.out.println("예외 처리: " + e.getMessage());
        }
    }
}
