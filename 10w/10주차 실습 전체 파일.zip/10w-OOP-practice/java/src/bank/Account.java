public class Account {
    private final String number;
    private int balance;

    public Account(String number, int balance) {
        if (number == null || number.isBlank()) {
            throw new IllegalArgumentException("계좌번호는 필수입니다.");
        }
        if (balance < 0) {
            throw new IllegalArgumentException("초기 잔액은 음수일 수 없습니다.");
        }
        this.number = number;
        this.balance = balance;
    }

    public String getNumber() {
        return number;
    }

    public int getBalance() {
        return balance;
    }

    public void deposit(int amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("입금액은 양수여야 합니다.");
        }
        balance += amount;
    }

    public void withdraw(int amount) {
        if (amount <= 0 || amount > balance) {
            throw new IllegalArgumentException("출금액이 올바르지 않습니다.");
        }
        balance -= amount;
    }

    @Override
    public String toString() {
        return "Account{number='" + number + "', balance=" + balance + "}";
    }
}
