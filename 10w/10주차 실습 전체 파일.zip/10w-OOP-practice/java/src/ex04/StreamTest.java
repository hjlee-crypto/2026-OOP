package ex04;
import java.util.List;
public class StreamTest {
    public static void main(String[] args) {
        List<Integer> balances = List.of(50000, 120000, 80000, 200000);
        balances.stream()
            .filter(b -> b >= 100000)
            .map(b -> b * 0.03)
            .forEach(System.out::println);
    }
}
