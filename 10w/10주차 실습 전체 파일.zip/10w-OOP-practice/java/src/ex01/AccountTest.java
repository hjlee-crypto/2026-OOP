package ex01;
public class AccountTest {
    public static void main(String[] args) {
        Account a = new Account("A-001", 100000);
        System.out.println(a.getNumber());
        System.out.println(a.getBalance());
    }
}
