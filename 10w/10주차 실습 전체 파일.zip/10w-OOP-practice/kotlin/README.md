# Kotlin 변환 결과 저장 위치
생성형 AI로 `java/src/ex07/` 및 `java/src/bank/`의 Java 소스를 Kotlin/JVM으로 변환한 후 이 폴더에 저장합니다.
기존 Java 소스와 클래스 이름이 중복되어 충돌하지 않도록 별도 Kotlin 프로젝트 또는 소스 루트에서 실행합니다.
실습 07-A~07-E는 변환 전·후 코드와 실행 결과를 `records/AI_실습기록.md`에 기록합니다.
